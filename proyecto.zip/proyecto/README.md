# Reporte de Proyecto final
### IEE2753 - Diseño de Circuitos Integrados Digitales

## Introducción

## Un poco de actualidad...
Hace poco tiempo fue anunciado un *PDK* open-source para el proceso **SKY130** del *SkyWater Technology Foundry*. El objetivo es poder expandir la posibilidad de fabricar *ASICs* a instituciones educativas, pequeñas empresas e individuales, quienes han tenido gran dificultad en incorporarse a los procesos debido a los altos costos, engorrosos *NDAs* y la necesidad de utilizar herramientas de diseño comerciales costosas (*Synopsys*, *Cadence*, *Mentor Graphics*, entre otras).

Como el proceso al que apunta este PDK es de 130nm, se esperaría poder implementar transistores con un largo de canal de 130nm.


## Preparación de la síntesis

Se apuntará a realizar un layout utilizando la librería `gsdl45`
